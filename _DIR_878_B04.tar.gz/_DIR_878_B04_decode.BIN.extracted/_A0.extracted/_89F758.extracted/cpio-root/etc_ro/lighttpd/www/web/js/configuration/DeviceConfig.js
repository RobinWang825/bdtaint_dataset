/*	===================================================	*/
/*				Device Default Configuration			*/
/*	Here you can define default setting for this device	*/
/*	===================================================	*/


var DebugMode;

/*	=================================================== */
/*	Debug Mode & Demo Mode								*/
/*	Enabled: [1]	Disabled: [0]						*/
DebugMode = 0;


