/* Initial Javascript - JavaScript (Timmy Hsieh)*/
/* Code Number: 130916							*/
document.write('<script type="text/javascript" charset="utf-8" src="/js/comm.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/hmac_md5.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/libajax.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/i18n.js"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="/js/configuration/DeviceConfig.js"></script>');
