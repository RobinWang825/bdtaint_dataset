var IPv6_Autodetection_profile = {
"autoDNS" : true,
"dhcpPD" : true,
"lanBlock" : ""
};

var IPv6_Static_profile = {
"autoDNS" : false,
"dhcpPD" : false,
"lanBlock" : ""
};

var IPv6_Autoconfig_profile = {
"autoDNS" : true,
"dhcpPD" : true,
"lanBlock" : ""
};

var IPv6_PPPoE_profile = {
"autoDNS" : true,
"dhcpPD" : true,
"lanBlock" : ""
};

var IPv6_6in4_profile = {
"autoDNS" : true,
"dhcpPD" : true,
"lanBlock" : ""
};

var IPv6_6to4_profile = {
"autoDNS" : false,
"dhcpPD" : false,
"lanBlock" : "6to4"
};

var IPv6_6rd_profile = {
"autoDNS" : false,
"dhcpPD" : false,
"lanBlock" : "6rd"
};

var IPv6_linklocal_profile = {
"autoDNS" : false,
"dhcpPD" : false,
"lanBlock" : "linklocal"
};
