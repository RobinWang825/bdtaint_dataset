//custom
function DeviceInfo()
{
	this.bridgeMode = false;
	this.featureVPN = false;

	this.featureUsbPort = false;
	this.featureSharePort = false;
	this.featureUserDevice = false;

	this.featureDLNA = false;
	this.featureUPNPAV = false;
	this.featureSmartConnect = false;
	this.featureMyDLink = false;

	this.helpVer = "";
}
