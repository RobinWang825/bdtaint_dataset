function SOAPGetWiFiSONSettings() {
    this.WiFiSONEnabled = false;
    this.MUMIMOEnabled = true;
    this.BandSteeringEnabled = true;
    this.AirTimeFairnessEnabled = true;
}
function SOAPSetWiFiSONSettings() {
    this.WiFiSONEnabled = false;
    this.MUMIMOEnabled = true;
    this.BandSteeringEnabled = true;
    this.AirTimeFairnessEnabled = true;
}
