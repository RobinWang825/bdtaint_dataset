//These settings will override common settings
function DeviceInfo()
{
	this.bridgeMode = true;
	this.featureVPN = true;

	this.featureUsbPort = true;
	this.featureSharePort = true;
	this.featureUserDevice = false;
	this.featureAutoRebootCfg = true;

	this.helpVer = "0100";
}
