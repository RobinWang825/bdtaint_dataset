//custom
function DeviceInfo()
{
	this.featureDLNA = true;

	this.featureUsbPort = true;
	this.featureSharePort = true;

	this.helpVer = "";
}
